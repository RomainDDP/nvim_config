return {
	"nvim-neo-tree/neo-tree.nvim",
	branch = "v3.x",
	dependencies = {
		"nvim-lua/plenary.nvim",
		"nvim-tree/nvim-web-devicons", -- Pour les petites icones de fichiers !
		"MunifTanjim/nui.nvim",
	},
	lazy = false, -- Neo-Tree se lazy load par lui même.

	opts = {
    	filesystem = {
      		hijack_netrw_behavior = "open_default",
    	},
  	},
}
